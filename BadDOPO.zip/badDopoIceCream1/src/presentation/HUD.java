package presentation;

import javax.swing.*;
import java.awt.*;

/**
 * HUD del juego, es la barrita que se ve en el juego de las frutas recogidas, el tiempo...
 */
public class HUD extends JPanel {
    
    private JLabel lblNivel;
    private JLabel lblFrutas;
    private JLabel lblTiempo;
    private JLabel lblPuntaje;
    
    public HUD() {
        configurarPanel();
        inicializarComponentes();
    }
    
    private void configurarPanel() {
        setPreferredSize(new Dimension(600, 60));
        setBackground(new Color(100, 150, 200));
        setLayout(new FlowLayout(FlowLayout.CENTER, 30, 15));
    }
    
    private void inicializarComponentes() {
        Font fuente = new Font("Arial", Font.BOLD, 14);
        Color colorTexto = Color.WHITE;
        
        // Label de nivel
        lblNivel = new JLabel("Nivel: 1");
        lblNivel.setFont(fuente);
        lblNivel.setForeground(colorTexto);
        add(lblNivel);
        
        // Label de frutas
        lblFrutas = new JLabel("Frutas: 0/16");
        lblFrutas.setFont(fuente);
        lblFrutas.setForeground(colorTexto);
        add(lblFrutas);
        
        // Label de tiempo
        lblTiempo = new JLabel("Tiempo: 3:00");
        lblTiempo.setFont(fuente);
        lblTiempo.setForeground(colorTexto);
        add(lblTiempo);
        
        // Label de puntaje
        lblPuntaje = new JLabel("Puntaje: 0");
        lblPuntaje.setFont(fuente);
        lblPuntaje.setForeground(colorTexto);
        add(lblPuntaje);
    }
    
    public void actualizarNivel(int nivel) {
        lblNivel.setText("Nivel: " + nivel);
    }
    
    
    public void actualizarFrutas(int recolectadas, int totales) {
        lblFrutas.setText("Frutas: " + recolectadas + "/" + totales);
    }
    
    public void actualizarTiempo(String tiempoFormateado) {
        lblTiempo.setText("Tiempo: " + tiempoFormateado);
        
        // Cambiar color si queda poco tiempo
        String[] partes = tiempoFormateado.split(":");
        if (partes.length == 2) {
            int minutos = Integer.parseInt(partes[0]);
            int segundos = Integer.parseInt(partes[1]);
            int totalSegundos = minutos * 60 + segundos;
            
            if (totalSegundos < 30) {
                lblTiempo.setForeground(new Color(255, 100, 100));
            } else {
                lblTiempo.setForeground(Color.WHITE);
            }
        }
    }
    
    public void actualizarPuntaje(int puntaje) {
        lblPuntaje.setText("Puntaje: " + puntaje);
    }
}