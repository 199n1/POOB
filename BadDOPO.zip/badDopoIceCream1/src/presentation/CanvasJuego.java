package presentation;

import domain.*;
import logic.GameEngine;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Canvas donde se dibuja el juego
 */
public class CanvasJuego extends JPanel implements KeyListener {
    
    private GameEngine gameEngine;
    private HUD hud;
    private Timer timer;
    private String modalidad;
    private String colorHelado;
    private boolean pausado;
    private JButton btnPausa;
    
    private int tamanoCelda; 
    
    private HashMap<String, Image> sprites;
    
    public CanvasJuego(String modalidad, String colorHelado, HUD hud) {
        this.modalidad = modalidad;
        this.colorHelado = colorHelado;
        this.hud = hud;
        this.pausado = false;
        this.tamanoCelda = 40;
        this.sprites = new HashMap<String, Image>();
        
        cargarSprites();
        configurarPanel();
        inicializarJuego();
        iniciarTimer();
    }
    
    private void cargarSprites() {
        sprites.put("helado_vainilla", cargarImagen("/resources/sprites/helado_vainilla.png"));
        sprites.put("helado_chocolate", cargarImagen("/resources/sprites/helado_chocolate.png"));
        sprites.put("helado_fresa", cargarImagen("/resources/sprites/helado_fresa.png"));
        
        sprites.put("uvas", cargarImagen("/resources/sprites/uvas.png"));
        sprites.put("banano", cargarImagen("/resources/sprites/banano.png"));
        sprites.put("cereza", cargarImagen("/resources/sprites/cereza.png"));
        sprites.put("pina", cargarImagen("/resources/sprites/pina.png"));
        sprites.put("cactus", cargarImagen("/resources/sprites/cactus.png"));
        sprites.put("cactus_puas", cargarImagen("/resources/sprites/cactus_puas.png"));
        
        sprites.put("troll", cargarImagen("/resources/sprites/troll.png"));
        sprites.put("maceta", cargarImagen("/resources/sprites/maceta.png"));
        sprites.put("calamar", cargarImagen("/resources/sprites/calamar.png"));
        
        sprites.put("bloque_hielo", cargarImagen("/resources/sprites/bloque_hielo.png"));
        sprites.put("fogata", cargarImagen("/resources/sprites/fogata.png"));
        sprites.put("fogata_apagada", cargarImagen("/resources/sprites/fogata_apagada.png"));
        sprites.put("baldosa_caliente", cargarImagen("/resources/sprites/baldosa_caliente.png"));
        sprites.put("iglu", cargarImagen("/resources/sprites/iglu.png"));
    }
    
    private Image cargarImagen(String ruta) {
        try {
            java.net.URL urlImagen = getClass().getResource(ruta);
            if (urlImagen != null) {
                return new ImageIcon(urlImagen).getImage();
            } else {
                System.err.println("No se encontro: " + ruta);
                return null;
            }
        } catch (Exception e) {
            System.err.println("Error al cargar: " + ruta);
            return null;
        }
    }
    
    private void configurarPanel() {
        setLayout(null);
        setBackground(new Color(230, 240, 255));
        setPreferredSize(new Dimension(600, 600));
        setMinimumSize(new Dimension(600, 600));
        setFocusable(true);
        addKeyListener(this);
        
        btnPausa = new JButton("PAUSAR");
        btnPausa.setBounds(450, 10, 120, 30);
        btnPausa.setFont(new Font("Arial", Font.BOLD, 12));
        btnPausa.setFocusable(false);
        btnPausa.addActionListener(new ListenerPausa(this));
        add(btnPausa);
    }
    
    public void togglePausa() {
        if (pausado) {
            timer.start();
            if (gameEngine != null) {
                gameEngine.getTemporizador().reanudar();
            }
            pausado = false;
            btnPausa.setText("PAUSAR");
            requestFocusInWindow();
        } else {
            timer.stop();
            if (gameEngine != null) {
                gameEngine.getTemporizador().pausar();
            }
            pausado = true;
            btnPausa.setText("REANUDAR");
        }
    }
    
    private void inicializarJuego() {
        try {
            gameEngine = new GameEngine(modalidad, colorHelado);
            actualizarHUD();
        } catch (GameException e) {
            JOptionPane.showMessageDialog(this, 
                "Error al inicializar: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void iniciarTimer() {
        timer = new Timer(16, new ListenerTimer(this));
        timer.start();
    }
    
    public void actualizarJuego() {
        if (gameEngine != null) {
            gameEngine.actualizar();
            actualizarHUD();
            repaint();
            verificarEstadoJuego();
        }
    }
    
    private void actualizarHUD() {
        if (hud == null || gameEngine == null) return;
        
        hud.actualizarFrutas(gameEngine.getFrutasRecolectadas(), 
                            gameEngine.getNivel().getTotalFrutas());
        hud.actualizarPuntaje(gameEngine.getPuntaje());
        hud.actualizarTiempo(gameEngine.getTiempoRestante());
        hud.actualizarNivel(gameEngine.getNumeroNivel());
    }
    
    private void verificarEstadoJuego() {
        if (gameEngine.isNivelCompletado()) {
            timer.stop();
            mostrarVictoria();
        } else if (gameEngine.isGameOver()) {
            timer.stop();
            mostrarGameOver("Perdiste!");
        } else if (gameEngine.getTemporizador().tiempoAgotado()) {
            timer.stop();
            mostrarGameOver("Tiempo agotado!");
        }
    }
    
    private void mostrarVictoria() {
        if (gameEngine.juegoCompletado()) {
            int opcion = JOptionPane.showConfirmDialog(this,
                "FELICIDADES! Completaste los 3 niveles!\n" +
                "Puntaje final: " + gameEngine.getPuntaje() + 
                "\nVolver al menu?",
                "Victoria!", JOptionPane.YES_NO_OPTION);
            
            if (opcion == JOptionPane.YES_OPTION) {
                volverAlMenu();
            }
        } else {
            int opcion = JOptionPane.showConfirmDialog(this,
                "Nivel " + gameEngine.getNumeroNivel() + " completado!\n" +
                "Puntaje: " + gameEngine.getPuntaje() + 
                "\nContinuar?",
                "Victoria!", JOptionPane.YES_NO_OPTION);
            
            if (opcion == JOptionPane.YES_OPTION) {
                try {
                    gameEngine.siguienteNivel();
                    actualizarHUD();
                    timer.start();
                } catch (GameException e) {
                    mostrarError("Error: " + e.getMessage());
                }
            } else {
                volverAlMenu();
            }
        }
    }
    
    private void mostrarGameOver(String mensaje) {
        int opcion = JOptionPane.showConfirmDialog(this,
            mensaje + "\nPuntaje: " + gameEngine.getPuntaje() +
            "\nReiniciar?",
            "Game Over", JOptionPane.YES_NO_OPTION);
        
        if (opcion == JOptionPane.YES_OPTION) {
            reiniciarJuego();
        } else {
            volverAlMenu();
        }
    }
    
    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, 
            "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void reiniciarJuego() {
        pausado = false;
        btnPausa.setText("PAUSAR");
        try {
            gameEngine.reiniciarJuego();
            actualizarHUD();
            timer.start();
            requestFocusInWindow();
        } catch (GameException e) {
            mostrarError("Error al reiniciar: " + e.getMessage());
        }
    }
    
    private void volverAlMenu() {
        timer.stop();
        Window ventana = SwingUtilities.getWindowAncestor(this);
        ventana.dispose();
        
        MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);
    }
    
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        if (gameEngine == null || gameEngine.getNivel() == null) {
            g.setColor(Color.RED);
            g.drawString("Cargando...", 250, 300);
            return;
        }
        
        Nivel nivel = gameEngine.getNivel();
        Mapa mapa = nivel.getMapa();
        
        if (mapa == null) return;
        
        dibujarBaldosasCalientes(g, nivel);
        dibujarBloques(g, mapa);
        dibujarFogatas(g, nivel);
        
        if (gameEngine.getNumeroNivel() == 1) {
            dibujarIglu(g);
        }
        
        dibujarFrutas(g, nivel);
        dibujarEnemigos(g, nivel);
        dibujarHelado(g, gameEngine.getHelado());
        
        if (gameEngine.getHelado2() != null) {
            dibujarHelado(g, gameEngine.getHelado2());
        }
        
        if (pausado) {
            g.setColor(new Color(0, 0, 0, 150));
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 40));
            g.drawString("PAUSADO", 200, 300);
        }
    }
    
    private void dibujarBaldosasCalientes(Graphics g, Nivel nivel) {
        Image img = sprites.get("baldosa_caliente");
        ArrayList<BaldosaCaliente> baldosas = nivel.getBaldosasCalientes();
        
        for (int i = 0; i < baldosas.size(); i++) {
            BaldosaCaliente baldosa = baldosas.get(i);
            int x = baldosa.getX() * tamanoCelda;
            int y = baldosa.getY() * tamanoCelda;
            
            if (img != null) {
                g.drawImage(img, x, y, tamanoCelda, tamanoCelda, this);
            } else {
                g.setColor(new Color(255, 100, 0, 100));
                g.fillRect(x, y, tamanoCelda, tamanoCelda);
            }
        }
    }
    
    private void dibujarBloques(Graphics g, Mapa mapa) {
        BloqueHielo[][] bloques = mapa.getBloques();
        Image imgBloque = sprites.get("bloque_hielo");
        
        for (int i = 0; i < bloques.length; i++) {
            for (int j = 0; j < bloques[i].length; j++) {
                if (bloques[i][j] != null && bloques[i][j].isActivo()) {
                    int x = j * tamanoCelda;
                    int y = i * tamanoCelda;
                    
                    if (imgBloque != null) {
                        g.drawImage(imgBloque, x, y, tamanoCelda, tamanoCelda, this);
                    } else {
                        g.setColor(new Color(150, 220, 255));
                        g.fillRect(x, y, tamanoCelda, tamanoCelda);
                        g.setColor(new Color(100, 180, 230));
                        g.drawRect(x, y, tamanoCelda, tamanoCelda);
                    }
                }
            }
        }
    }
    
    private void dibujarFogatas(Graphics g, Nivel nivel) {
        ArrayList<Fogata> fogatas = nivel.getFogatas();
        
        for (int i = 0; i < fogatas.size(); i++) {
            Fogata fogata = fogatas.get(i);
            int x = fogata.getX() * tamanoCelda;
            int y = fogata.getY() * tamanoCelda;
            
            Image img;
            if (fogata.estaEncendida()) {
                img = sprites.get("fogata");
            } else {
                img = sprites.get("fogata_apagada");
            }
            
            if (img != null) {
                g.drawImage(img, x, y, tamanoCelda, tamanoCelda, this);
            } else {
                if (fogata.estaEncendida()) {
                    g.setColor(new Color(255, 100, 0));
                    g.fillOval(x + 10, y + 10, tamanoCelda - 20, tamanoCelda - 20);
                } else {
                    g.setColor(Color.GRAY);
                    g.fillOval(x + 10, y + 10, tamanoCelda - 20, tamanoCelda - 20);
                }
            }
        }
    }
    
    private void dibujarIglu(Graphics g) {
        int centroX = 7 * tamanoCelda;
        int centroY = 7 * tamanoCelda;
        int tamanio = tamanoCelda * 2;
        
        Image imgIglu = sprites.get("iglu");
        
        if (imgIglu != null) {
            g.drawImage(imgIglu, centroX - tamanoCelda / 2, centroY - tamanoCelda / 2, 
                       tamanio, tamanio, this);
        } else {
            int radio = tamanoCelda * 2;
            centroX = centroX + tamanoCelda / 2;
            centroY = centroY + tamanoCelda / 2;
            
            g.setColor(new Color(180, 220, 240));
            g.fillOval(centroX - radio, centroY - radio, radio * 2, radio * 2);
        }
    }
    
    private void dibujarFrutas(Graphics g, Nivel nivel) {
        ArrayList<Fruta> frutas = nivel.getFrutas();
        int tamanoFruta = tamanoCelda * 2 / 3;
        int offset = (tamanoCelda - tamanoFruta) / 2;
        
        for (int i = 0; i < frutas.size(); i++) {
            Fruta fruta = frutas.get(i);
            if (!fruta.isActiva()) continue;
            
            int x = fruta.getX() * tamanoCelda + offset;
            int y = fruta.getY() * tamanoCelda + offset;
            
            String nombreSprite = obtenerNombreSpriteFruta(fruta);
            Image imgFruta = sprites.get(nombreSprite);
            
            if (imgFruta != null) {
                g.drawImage(imgFruta, x, y, tamanoFruta, tamanoFruta, this);
            } else {
                dibujarFrutaSimple(g, fruta, x, y, tamanoFruta);
            }
        }
    }
    
    private String obtenerNombreSpriteFruta(Fruta fruta) {
        if (fruta instanceof Uvas) {
            return "uvas";
        }
        if (fruta instanceof Banano) {
            return "banano";
        }
        if (fruta instanceof Cereza) {
            return "cereza";
        }
        if (fruta instanceof Pina) {
            return "pina";
        }
        if (fruta instanceof Cactus) {
            Cactus cactus = (Cactus) fruta;
            if (cactus.tienePuas()) {
                return "cactus_puas";
            } else {
                return "cactus";
            }
        }
        return "";
    }
    
    private void dibujarFrutaSimple(Graphics g, Fruta fruta, int x, int y, int tam) {
        if (fruta instanceof Uvas) {
            g.setColor(new Color(128, 0, 128));
            g.fillOval(x, y, tam, tam);
        } else if (fruta instanceof Banano) {
            g.setColor(Color.YELLOW);
            g.fillOval(x, y, tam * 3 / 4, tam);
        } else if (fruta instanceof Cereza) {
            g.setColor(Color.RED);
            g.fillOval(x, y, tam, tam);
        } else if (fruta instanceof Pina) {
            g.setColor(new Color(255, 200, 0));
            g.fillOval(x, y, tam, tam);
        } else if (fruta instanceof Cactus) {
            Cactus cactus = (Cactus) fruta;
            if (cactus.tienePuas()) {
                g.setColor(Color.RED);
            } else {
                g.setColor(Color.GREEN);
            }
            g.fillRect(x, y, tam, tam);
        }
    }
    
    private void dibujarEnemigos(Graphics g, Nivel nivel) {
        ArrayList<Enemigo> enemigos = nivel.getEnemigos();
        int tamanoEnemigo = tamanoCelda + 5;
        int offset = -2;
        
        for (int i = 0; i < enemigos.size(); i++) {
            Enemigo enemigo = enemigos.get(i);
            if (!enemigo.isActivo()) continue;
            
            int x = enemigo.getX() * tamanoCelda + offset;
            int y = enemigo.getY() * tamanoCelda + offset;
            
            String nombreSprite = obtenerNombreSpriteEnemigo(enemigo);
            Image imgEnemigo = sprites.get(nombreSprite);
            
            if (imgEnemigo != null) {
                g.drawImage(imgEnemigo, x, y, tamanoEnemigo, tamanoEnemigo, this);
            } else {
                dibujarEnemigoSimple(g, enemigo, x, y, tamanoEnemigo);
            }
        }
    }
    
    private String obtenerNombreSpriteEnemigo(Enemigo enemigo) {
        if (enemigo instanceof Troll) {
            return "troll";
        }
        if (enemigo instanceof Maceta) {
            return "maceta";
        }
        if (enemigo instanceof Calamar) {
            return "calamar";
        }
        return "";
    }
    
    private void dibujarEnemigoSimple(Graphics g, Enemigo enemigo, int x, int y, int tam) {
        if (enemigo instanceof Troll) {
            g.setColor(new Color(100, 150, 50));
            g.fillRect(x + 5, y + 10, tam - 10, tam - 10);
        } else if (enemigo instanceof Maceta) {
            g.setColor(new Color(150, 75, 0));
            g.fillRect(x, y, tam, tam);
        } else if (enemigo instanceof Calamar) {
            g.setColor(new Color(255, 140, 0));
            g.fillOval(x, y, tam, tam);
        }
    }
    
    private void dibujarHelado(Graphics g, Helado helado) {
        if (helado == null || !helado.isVivo()) return;
        
        int tamanoHelado = tamanoCelda + 5;
        int offset = -2;
        
        int x = helado.getX() * tamanoCelda + offset;
        int y = helado.getY() * tamanoCelda + offset;
        
        String sabor = helado.getSabor();
        String nombreSprite = "helado_" + sabor.toLowerCase();
        Image imgHelado = sprites.get(nombreSprite);
        
        if (imgHelado != null) {
            g.drawImage(imgHelado, x, y, tamanoHelado, tamanoHelado, this);
        } else {
            dibujarHeladoSimple(g, helado, x, y, tamanoHelado);
        }
    }
    
    private void dibujarHeladoSimple(Graphics g, Helado helado, int x, int y, int tam) {
        Color colorBola = obtenerColorHelado(helado);
        
        int[] xPoints = {x + tam / 2, x + 10, x + tam - 10};
        int[] yPoints = {y + tam - 5, y + tam / 2, y + tam / 2};
        
        g.setColor(new Color(210, 180, 140));
        g.fillPolygon(xPoints, yPoints, 3);
        
        int radioBola = tam / 3;
        g.setColor(colorBola);
        g.fillOval(x + tam / 2 - radioBola, y + 5, radioBola * 2, radioBola * 2);
    }
    
    private Color obtenerColorHelado(Helado helado) {
        String sabor = helado.getSabor();
        
        if (sabor.equals("Vainilla")) {
            return new Color(255, 250, 240);
        } else if (sabor.equals("Chocolate")) {
            return new Color(139, 69, 19);
        } else if (sabor.equals("Fresa")) {
            return new Color(255, 182, 193);
        }
        return Color.WHITE;
    }
    
    // CONTROLES
    public void keyPressed(KeyEvent e) {
        if (pausado || gameEngine == null) return;
        if (gameEngine.isNivelCompletado() || gameEngine.isGameOver()) return;
        
        int tecla = e.getKeyCode();
        
        // JUGADOR 1: Flechas
        if (tecla == KeyEvent.VK_UP) {
            gameEngine.moverHelado("arriba");
        } else if (tecla == KeyEvent.VK_DOWN) {
            gameEngine.moverHelado("abajo");
        } else if (tecla == KeyEvent.VK_LEFT) {
            gameEngine.moverHelado("izquierda");
        } else if (tecla == KeyEvent.VK_RIGHT) {
            gameEngine.moverHelado("derecha");
        } else if (tecla == KeyEvent.VK_ENTER) {
            gameEngine.accionBloque();
        } else if (tecla == KeyEvent.VK_SPACE) {
            if (gameEngine.getHelado() != null && gameEngine.getHelado().isVivo()) {
                gameEngine.getHelado().romperBloques();
            }
        }
        
        // JUGADOR 2: WASD (solo en PvsP)
        if (modalidad.equals("PvsP") && gameEngine.getHelado2() != null) {
            Helado helado2 = gameEngine.getHelado2();
            
            if (tecla == KeyEvent.VK_W) {
                helado2.mover("arriba");
            } else if (tecla == KeyEvent.VK_S) {
                helado2.mover("abajo");
            } else if (tecla == KeyEvent.VK_A) {
                helado2.mover("izquierda");
            } else if (tecla == KeyEvent.VK_D) {
                helado2.mover("derecha");
            } else if (tecla == KeyEvent.VK_CONTROL) {
                helado2.crearBloques();
            } else if (tecla == KeyEvent.VK_F) {
                helado2.romperBloques();
            }
        }
        
        // Pausa
        if (tecla == KeyEvent.VK_P || tecla == KeyEvent.VK_ESCAPE) {
            togglePausa();
        }
    }
    
    public void keyReleased(KeyEvent e) {}
    
    public void keyTyped(KeyEvent e) {}
    
    // CLASES INTERNAS SIMPLES
    
    private class ListenerPausa implements ActionListener {
        private CanvasJuego canvas;
        
        public ListenerPausa(CanvasJuego canvas) {
            this.canvas = canvas;
        }
        
        public void actionPerformed(ActionEvent e) {
            canvas.togglePausa();
        }
    }
    
    private class ListenerTimer implements ActionListener {
        private CanvasJuego canvas;
        
        public ListenerTimer(CanvasJuego canvas) {
            this.canvas = canvas;
        }
        
        public void actionPerformed(ActionEvent e) {
            canvas.actualizarJuego();
        }
    }
}