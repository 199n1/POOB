package domain;

/**
 * Cactus: fruta estática que cada 30s activa púas
 * Otorga 250 puntos
 */
public class Cactus extends Fruta {
    private boolean peligroso;
    private int contadorFrames;
    private static final int FRAMES_CAMBIO = 1800; // 30s a 60FPS

    public Cactus(int x, int y) {
        super(x, y, 250);
        this.peligroso = false;
        this.contadorFrames = 0;
    }

    @Override
    public String getTipo() { return "Cactus"; }

    @Override
    public void actualizar() {
        if (!activa) return;
        contadorFrames++;
        if (contadorFrames >= FRAMES_CAMBIO) {
            peligroso = !peligroso; // alterna estado
            contadorFrames = 0;
        }
    }

    public boolean esPeligroso() { return peligroso; }
    public boolean puedeSerRecolectado() { return !peligroso; }
    public boolean tienePuas() { return peligroso; }
}