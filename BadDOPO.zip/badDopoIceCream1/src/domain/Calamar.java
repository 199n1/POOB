package domain;

/**
 * Calamar: Persigue al helado y rompe UN bloque a la vez cuando lo encuentra
 */
public class Calamar extends Enemigo {
    private Helado objetivo;
    private int contadorFrames;

    public Calamar(int x, int y, Mapa mapa, Helado objetivo) throws GameException {
        super(x, y, mapa);
        this.objetivo = objetivo;
        this.contadorFrames = 0;
    }

    @Override
    public void actualizar() {
        if (!activo) return;
        contadorFrames++;
        if (contadorFrames >= 25) { // Cada ~0.4 segundos
            mover();
            contadorFrames = 0;
        }
    }

    @Override
    public void mover() {
        if (objetivo == null || !objetivo.isVivo()) return;

        // Calcular diferencia de posición
        int dx = objetivo.getX() - x;
        int dy = objetivo.getY() - y;

        int nx = x;
        int ny = y;

        // Moverse hacia el helado (prioridad horizontal o vertical)
        if (Math.abs(dx) > Math.abs(dy)) {
            // Moverse horizontalmente
            if (dx > 0) {
                nx++;
                direccion = "derecha";
            } else if (dx < 0) {
                nx--;
                direccion = "izquierda";
            }
        } else {
            // Moverse verticalmente
            if (dy > 0) {
                ny++;
                direccion = "abajo";
            } else if (dy < 0) {
                ny--;
                direccion = "arriba";
            }
        }

        // Verificar si hay un bloque en la siguiente posición
        BloqueHielo bloque = mapa.getBloque(nx, ny);
        
        if (bloque != null && bloque.isActivo() && !bloque.isPermanente()) {
            // HAY UN BLOQUE: Destruirlo y NO moverse
            bloque.destruir();
            mapa.setBloque(nx, ny, null);
            return; // Se detiene después de romper el bloque
        }

        // NO hay bloque: Moverse normalmente
        if (posicionValida(nx, ny)) {
            x = nx;
            y = ny;
        }
    }
}