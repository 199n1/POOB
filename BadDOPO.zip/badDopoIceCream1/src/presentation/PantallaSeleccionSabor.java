package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Pantalla para seleccionar sabor de helado 
 */
public class PantallaSeleccionSabor extends JFrame {
    
    private String modalidad;
    private boolean dosJugadores;
    private String saborJugador1;
    private String saborJugador2;
    private Image fondoImagen;
    
    private Image imgVainilla;
    private Image imgChocolate;
    private Image imgFresa;
    
    private JLabel lblSeleccionJ1;
    private JLabel lblSeleccionJ2;
    
    public PantallaSeleccionSabor(String modalidad) {
        this.modalidad = modalidad;
        this.dosJugadores = modalidad.equals("PvsP");
        this.saborJugador1 = null;
        this.saborJugador2 = null;
        
        cargarImagenes();
        configurarVentana();
        inicializarComponentes();
    }
    
    private void cargarImagenes() {
        try {
            java.net.URL imgURL = getClass().getResource("/resources/imagenes/fondo_sabor.png");
            if (imgURL != null) {
                fondoImagen = new ImageIcon(imgURL).getImage();
            }
            
            imgVainilla = cargarImagen("/resources/sprites/helado_vainilla.png");
            imgChocolate = cargarImagen("/resources/sprites/helado_chocolate.png");
            imgFresa = cargarImagen("/resources/sprites/helado_fresa.png");
            
        } catch (Exception e) {
            System.err.println("Error al cargar imagenes: " + e.getMessage());
        }
    }
    
    private Image cargarImagen(String path) {
        try {
            java.net.URL imgURL = getClass().getResource(path);
            if (imgURL != null) {
                return new ImageIcon(imgURL).getImage();
            }
        } catch (Exception e) {
            System.err.println("Error al cargar: " + path);
        }
        return null;
    }
    
    private void configurarVentana() {
        setTitle("Seleccionar Sabor - Bad DOPO Cream");
        if (dosJugadores) {
            setSize(600, 500);
        } else {
            setSize(500, 500);
        }
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (fondoImagen != null) {
                    g.drawImage(fondoImagen, 0, 0, getWidth(), getHeight(), this);
                } else {
                    g.setColor(new Color(200, 230, 255));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        
        panelPrincipal.setLayout(null);
        panelPrincipal.setOpaque(false);
        
        if (dosJugadores) {
            crearPantalla2Jugadores(panelPrincipal);
        } else {
            crearPantalla1Jugador(panelPrincipal);
        }
        
        add(panelPrincipal);
    }
    
    // ==================== PANTALLA 1 JUGADOR ====================
    
    private void crearPantalla1Jugador(JPanel panel) {
        JLabel titulo = new JLabel("ELIGE TU SABOR DE HELADO", SwingConstants.CENTER);
        titulo.setFont(new Font("Impact", Font.BOLD, 26));
        titulo.setForeground(new Color(101, 67, 33));
        titulo.setBounds(0, 30, 500, 35);
        panel.add(titulo);
        
        JLabel lblModalidad = new JLabel("Modalidad: " + obtenerNombreModalidad(), SwingConstants.CENTER);
        lblModalidad.setFont(new Font("Arial", Font.ITALIC, 14));
        lblModalidad.setForeground(new Color(70, 70, 70));
        lblModalidad.setBounds(0, 70, 500, 20);
        panel.add(lblModalidad);
        
        int yInicial = 130;
        int espaciado = 110;
        
        JButton btnVainilla = agregarHeladoBoton(panel, imgVainilla, "VAINILLA", 
            new Color(255, 250, 240), Color.BLACK, 90, yInicial, 1);
        btnVainilla.addActionListener(new ListenerSabor(this, "Vainilla", 1));
        
        JButton btnChocolate = agregarHeladoBoton(panel, imgChocolate, "CHOCOLATE", 
            new Color(139, 69, 19), Color.WHITE, 90, yInicial + espaciado, 1);
        btnChocolate.addActionListener(new ListenerSabor(this, "Chocolate", 1));
        
        JButton btnFresa = agregarHeladoBoton(panel, imgFresa, "FRESA", 
            new Color(255, 182, 193), Color.BLACK, 90, yInicial + espaciado * 2, 1);
        btnFresa.addActionListener(new ListenerSabor(this, "Fresa", 1));
        
        JButton btnAtras = new JButton("ATRAS");
        btnAtras.setFont(new Font("Arial", Font.BOLD, 14));
        btnAtras.setBounds(175, 430, 150, 35);
        btnAtras.setBackground(new Color(149, 165, 166));
        btnAtras.setForeground(Color.WHITE);
        btnAtras.setFocusPainted(false);
        btnAtras.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        btnAtras.addActionListener(new ListenerAtras(this));
        panel.add(btnAtras);
    }
    
    private JButton agregarHeladoBoton(JPanel panel, Image imagen, String sabor, 
                                    Color colorFondo, Color colorTexto, 
                                    int x, int y, int jugador) {
        JButton btnHelado = new JButton() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (imagen != null) {
                    int tamImagen = 50;
                    int xImg = 20;
                    int yImg = (getHeight() - tamImagen) / 2;
                    g.drawImage(imagen, xImg, yImg, tamImagen, tamImagen, this);
                }
            }
        };
        
        btnHelado.setText(sabor);
        btnHelado.setFont(new Font("Arial", Font.BOLD, 22));
        btnHelado.setBounds(x, y, 320, 70);
        btnHelado.setBackground(colorFondo);
        btnHelado.setForeground(colorTexto);
        btnHelado.setFocusPainted(false);
        btnHelado.setHorizontalAlignment(SwingConstants.CENTER);
        btnHelado.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.BLACK, 3),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        panel.add(btnHelado);
        return btnHelado;
    }
    
    // ==================== PANTALLA 2 JUGADORES ====================
    
    private void crearPantalla2Jugadores(JPanel panel) {
        JLabel titulo = new JLabel("CHOOSE YOUR FLAVOUR!", SwingConstants.CENTER);
        titulo.setFont(new Font("Impact", Font.BOLD, 28));
        titulo.setForeground(new Color(101, 67, 33));
        titulo.setBounds(0, 20, 600, 35);
        panel.add(titulo);
        
        JLabel lblPlayer1 = new JLabel("PLAYER 1", SwingConstants.CENTER);
        lblPlayer1.setFont(new Font("Arial", Font.BOLD, 16));
        lblPlayer1.setForeground(new Color(101, 67, 33));
        lblPlayer1.setBounds(80, 80, 150, 25);
        panel.add(lblPlayer1);
        
        JLabel lblPlayer2 = new JLabel("PLAYER 2", SwingConstants.CENTER);
        lblPlayer2.setFont(new Font("Arial", Font.BOLD, 16));
        lblPlayer2.setForeground(new Color(101, 67, 33));
        lblPlayer2.setBounds(370, 80, 150, 25);
        panel.add(lblPlayer2);
        
        int yHelados = 120;
        agregarHeladoSeleccionable(panel, imgVainilla, "Vainilla", 50, yHelados, 1);
        agregarHeladoSeleccionable(panel, imgChocolate, "Chocolate", 50, yHelados + 90, 1);
        agregarHeladoSeleccionable(panel, imgFresa, "Fresa", 50, yHelados + 180, 1);
        
        agregarHeladoSeleccionable(panel, imgVainilla, "Vainilla", 420, yHelados, 2);
        agregarHeladoSeleccionable(panel, imgChocolate, "Chocolate", 420, yHelados + 90, 2);
        agregarHeladoSeleccionable(panel, imgFresa, "Fresa", 420, yHelados + 180, 2);
        
        lblSeleccionJ1 = new JLabel("Selecciona tu helado", SwingConstants.CENTER);
        lblSeleccionJ1.setFont(new Font("Arial", Font.ITALIC, 12));
        lblSeleccionJ1.setForeground(Color.RED);
        lblSeleccionJ1.setBounds(50, 410, 150, 20);
        panel.add(lblSeleccionJ1);
        
        lblSeleccionJ2 = new JLabel("Selecciona tu helado", SwingConstants.CENTER);
        lblSeleccionJ2.setFont(new Font("Arial", Font.ITALIC, 12));
        lblSeleccionJ2.setForeground(Color.RED);
        lblSeleccionJ2.setBounds(400, 410, 150, 20);
        panel.add(lblSeleccionJ2);
        
        JButton btnBack = new JButton("BACK");
        btnBack.setFont(new Font("Arial", Font.BOLD, 14));
        btnBack.setBounds(250, 440, 100, 30);
        btnBack.setBackground(new Color(192, 192, 192));
        btnBack.setFocusPainted(false);
        btnBack.addActionListener(new ListenerAtras(this));
        panel.add(btnBack);
    }
    
    private void agregarHeladoSeleccionable(JPanel panel, Image imagen, String sabor, int x, int y, int jugador) {
        JButton btnHelado = new JButton() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (imagen != null) {
                    g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
                } else {
                    g.setColor(obtenerColorSabor(sabor));
                    g.fillOval(10, 10, 60, 60);
                }
            }
        };
        
        btnHelado.setBounds(x, y, 80, 80);
        btnHelado.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        btnHelado.setContentAreaFilled(false);
        btnHelado.setFocusPainted(false);
        btnHelado.addActionListener(new ListenerSabor(this, sabor, jugador));
        
        panel.add(btnHelado);
        
        JLabel lblNombre = new JLabel(sabor, SwingConstants.CENTER);
        lblNombre.setFont(new Font("Arial", Font.PLAIN, 12));
        lblNombre.setForeground(new Color(101, 67, 33));
        lblNombre.setBounds(x - 20, y + 85, 120, 15);
        panel.add(lblNombre);
    }
    
    // ==================== LOGICA ====================
    
    public void seleccionarSabor(String sabor, int jugador) {
        if (dosJugadores) {
            if (jugador == 1) {
                saborJugador1 = sabor;
                lblSeleccionJ1.setText("✓ " + sabor);
                lblSeleccionJ1.setForeground(new Color(46, 204, 113));
            } else {
                saborJugador2 = sabor;
                lblSeleccionJ2.setText("✓ " + sabor);
                lblSeleccionJ2.setForeground(new Color(46, 204, 113));
            }
            
            if (saborJugador1 != null && saborJugador2 != null) {
                continuar();
            }
        } else {
            saborJugador1 = sabor;
            continuar();
        }
    }
    
    private void continuar() {
        dispose();
        PantallaConfiguracionNiveles pantalla = new PantallaConfiguracionNiveles(modalidad, saborJugador1);
        pantalla.setVisible(true);
    }
    
    private String obtenerNombreModalidad() {
        if (modalidad.equals("Player")) {
            return "Un Jugador";
        }
        if (modalidad.equals("PvsP")) {
            return "2 Jugadores";
        }
        return modalidad;
    }
    
    private Color obtenerColorSabor(String sabor) {
        if (sabor.equals("Vainilla")) {
            return new Color(255, 250, 240);
        }
        if (sabor.equals("Chocolate")) {
            return new Color(139, 69, 19);
        }
        if (sabor.equals("Fresa")) {
            return new Color(255, 182, 193);
        }
        return Color.WHITE;
    }
    
    // ==================== CLASES INTERNAS ====================
    
    private class ListenerSabor implements ActionListener {
        private PantallaSeleccionSabor ventana;
        private String sabor;
        private int jugador;
        
        public ListenerSabor(PantallaSeleccionSabor ventana, String sabor, int jugador) {
            this.ventana = ventana;
            this.sabor = sabor;
            this.jugador = jugador;
        }
        
        public void actionPerformed(ActionEvent e) {
            ventana.seleccionarSabor(sabor, jugador);
        }
    }
    
    private class ListenerAtras implements ActionListener {
        private PantallaSeleccionSabor ventana;
        
        public ListenerAtras(PantallaSeleccionSabor ventana) {
            this.ventana = ventana;
        }
        
        public void actionPerformed(ActionEvent e) {
            ventana.dispose();
            PantallaSeleccionModalidad pantalla = new PantallaSeleccionModalidad();
            pantalla.setVisible(true);
        }
    }
}