package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Pantalla para seleccionar la modalidad del juego
 * Solo Player y PvsP están implementados
 */
public class PantallaSeleccionModalidad extends JFrame {
    
    private Image fondoImagen;
    
    public PantallaSeleccionModalidad() {
        cargarFondo();
        configurarVentana();
        inicializarComponentes();
    }
    
    private void cargarFondo() {
        try {
            java.net.URL imgURL = getClass().getResource("/resources/imagenes/fondo_modalidad.png");
            if (imgURL != null) {
                fondoImagen = new ImageIcon(imgURL).getImage();
            }
        } catch (Exception e) {
            System.err.println("Error al cargar fondo: " + e.getMessage());
        }
    }
    
    private void configurarVentana() {
        setTitle("Seleccionar Modalidad - Bad DOPO Cream");
        setSize(550, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (fondoImagen != null) {
                    g.drawImage(fondoImagen, 0, 0, getWidth(), getHeight(), this);
                } else {
                    g.setColor(new Color(200, 230, 255));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        
        panelPrincipal.setLayout(null);
        panelPrincipal.setOpaque(false);
        
        // Titulo
        JLabel titulo = new JLabel("SELECCIONA LA MODALIDAD", SwingConstants.CENTER);
        titulo.setFont(new Font("Impact", Font.BOLD, 32));
        titulo.setForeground(Color.WHITE);
        titulo.setBounds(50, 30, 450, 40);
        panelPrincipal.add(titulo);
        
        // Boton 1: PLAYER
        JButton btnPlayer = crearBotonModalidad("PLAYER", "Un jugador controla un helado", 100);
        btnPlayer.addActionListener(new ListenerPlayer(this));
        panelPrincipal.add(btnPlayer);
        
        // Boton 2: PLAYER vs PLAYER
        JButton btnPvsP = crearBotonModalidad("PLAYER vs PLAYER", "Dos jugadores compiten", 200);
        btnPvsP.addActionListener(new ListenerPvsP(this));
        panelPrincipal.add(btnPvsP);
        
        // Boton 3: PLAYER vs MACHINE (NO IMPLEMENTADO)
        JButton btnPvsM = crearBotonModalidad("PLAYER vs MACHINE", "Jugador contra máquina", 300);
        btnPvsM.addActionListener(new ListenerNoImplementado(this));
        panelPrincipal.add(btnPvsM);
        
        // Boton 4: MACHINE vs MACHINE (NO IMPLEMENTADO)
        JButton btnMvsM = crearBotonModalidad("MACHINE vs MACHINE", "Dos máquinas compiten", 400);
        btnMvsM.addActionListener(new ListenerNoImplementado(this));
        panelPrincipal.add(btnMvsM);
        
        // Boton ATRAS
        JButton btnAtras = new JButton("ATRAS");
        btnAtras.setFont(new Font("Arial", Font.BOLD, 14));
        btnAtras.setBounds(200, 550, 150, 40);
        btnAtras.setBackground(new Color(149, 165, 166));
        btnAtras.setForeground(Color.WHITE);
        btnAtras.setFocusPainted(false);
        btnAtras.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        btnAtras.addActionListener(new ListenerAtras(this));
        panelPrincipal.add(btnAtras);
        
        add(panelPrincipal);
    }
    
    private JButton crearBotonModalidad(String titulo, String descripcion, int y) {
        JButton boton = new JButton();
        boton.setLayout(new BorderLayout());
        boton.setBounds(65, y, 420, 75);
        boton.setBackground(new Color(41, 128, 185));
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 2),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        
        JLabel lblTitulo = new JLabel(titulo, SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        lblTitulo.setForeground(Color.WHITE);
        
        JLabel lblDescripcion = new JLabel(descripcion, SwingConstants.CENTER);
        lblDescripcion.setFont(new Font("Arial", Font.ITALIC, 12));
        lblDescripcion.setForeground(new Color(236, 240, 241));
        
        JPanel contenido = new JPanel();
        contenido.setLayout(new BoxLayout(contenido, BoxLayout.Y_AXIS));
        contenido.setOpaque(false);
        contenido.add(lblTitulo);
        contenido.add(Box.createRigidArea(new Dimension(0, 5)));
        contenido.add(lblDescripcion);
        
        boton.add(contenido, BorderLayout.CENTER);
        
        return boton;
    }
    
    // Clase interna para el boton Player
    private class ListenerPlayer implements ActionListener {
        private PantallaSeleccionModalidad ventana;
        
        public ListenerPlayer(PantallaSeleccionModalidad ventana) {
            this.ventana = ventana;
        }
        
        public void actionPerformed(ActionEvent e) {
            ventana.dispose();
            PantallaSeleccionSabor pantalla = new PantallaSeleccionSabor("Player");
            pantalla.setVisible(true);
        }
    }
    
    // Clase interna para el boton PvsP
    private class ListenerPvsP implements ActionListener {
        private PantallaSeleccionModalidad ventana;
        
        public ListenerPvsP(PantallaSeleccionModalidad ventana) {
            this.ventana = ventana;
        }
        
        public void actionPerformed(ActionEvent e) {
            ventana.dispose();
            PantallaSeleccionSabor pantalla = new PantallaSeleccionSabor("PvsP");
            pantalla.setVisible(true);
        }
    }
    
    // Clase interna para botones NO implementados
    private class ListenerNoImplementado implements ActionListener {
        private PantallaSeleccionModalidad ventana;
        
        public ListenerNoImplementado(PantallaSeleccionModalidad ventana) {
            this.ventana = ventana;
        }
        
        public void actionPerformed(ActionEvent e) {
            JOptionPane.showMessageDialog(ventana,
                "Esta modalidad todavia no esta implementada.\n" +
                "Por favor selecciona Player o Player vs Player.",
                "Funcion no disponible",
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    // Clase interna para el boton Atras
    private class ListenerAtras implements ActionListener {
        private PantallaSeleccionModalidad ventana;
        
        public ListenerAtras(PantallaSeleccionModalidad ventana) {
            this.ventana = ventana;
        }
        
        public void actionPerformed(ActionEvent e) {
            ventana.dispose();
            MenuPrincipal menu = new MenuPrincipal();
            menu.setVisible(true);
        }
    }
}