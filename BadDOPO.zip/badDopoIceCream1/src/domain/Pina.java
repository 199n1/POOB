package domain;

/**
 * Piña: se mueve en direccion contraria al helado
 * Si el helado va arriba, la piña va abajo
 * Otorga 200 puntos
 */
public class Pina extends Fruta {
    private Mapa mapa;

    public Pina(int x, int y, Mapa mapa) {
        super(x, y, 200);
        this.mapa = mapa;
    }

    @Override
    public String getTipo() { return "Pina"; }

    @Override
    public void actualizar() { /* se mueve solo con el helado */ }

    /**
     * Mueve la piña en la dirección OPUESTA al helado
     */
    public void moverConHelado(String direccionHelado) {
        if (!activa) return;
        
        int nx = x, ny = y;
        
        // INVERTIR la dirección del helado
        if (direccionHelado.equals("arriba")) {
            ny++; // Piña va ABAJO
        } else if (direccionHelado.equals("abajo")) {
            ny--; // Piña va ARRIBA
        } else if (direccionHelado.equals("izquierda")) {
            nx++; // Piña va DERECHA
        } else if (direccionHelado.equals("derecha")) {
            nx--; // Piña va IZQUIERDA
        }

        // No entrar al iglú si el mapa es de hielo
        if (mapa.getTipo() == TipoObstaculoMapa.HIELO) {
            if (nx >= 6 && nx <= 8 && ny >= 6 && ny <= 8) return;
        }

        // Mover si la posición es válida
        if (mapa.dentroLimites(nx, ny) && mapa.posicionLibre(nx, ny)) {
            this.x = nx;
            this.y = ny;
        }
    }
}