package domain;

import java.util.*;

/**
 * Clase Nivel con oleadas en posiciones fijas
 */
public class Nivel {
    private int numeroNivel;
    private Mapa mapa;
    private ArrayList<Fruta> frutas;
    private ArrayList<Enemigo> enemigos;
    private ArrayList<Fogata> fogatas;
    private ArrayList<BaldosaCaliente> baldosasCalientes;
    private Helado helado;
    private int frutasRecolectadas;
    private int totalFrutas;
    
    private boolean oleada1Completa;
    private boolean[] frutasRecolectadasArray; // Para trackear qué frutas se recolectaron
    
    // POSICIONES FIJAS para las oleadas (como en la imagen)
    private static final int[][] POSICIONES_OLEADA_1 = {
        {2, 9}, {4, 9}, {6, 9}, {8, 9}, {10, 9}, {12, 9}, {2, 10}, {4, 10}
    };
    
    private static final int[][] POSICIONES_OLEADA_2 = {
        {6, 10}, {8, 10}, {10, 10}, {12, 10}, {2, 12}, {4, 12}, {6, 12}, {8, 12}
    };

    public Nivel(int numeroNivel, Helado helado,
                 TipoObstaculoMapa obstaculo,
                 TipoFruta fruta1,
                 TipoFruta fruta2,
                 TipoEnemigo enemigo) throws GameException {
        this.numeroNivel = numeroNivel;
        this.helado = helado;
        this.frutas = new ArrayList<>();
        this.enemigos = new ArrayList<>();
        this.fogatas = new ArrayList<>();
        this.baldosasCalientes = new ArrayList<>();
        this.oleada1Completa = false;
        this.frutasRecolectadasArray = new boolean[16]; // 16 frutas en total

        mapa = new Mapa(15, 15, numeroNivel, obstaculo);

        configurarFrutasEnOleadas(fruta1, fruta2);
        configurarEnemigo(enemigo);

        if (obstaculo == TipoObstaculoMapa.BALDOSA_CALIENTE) {
            crearBaldosasCalientes();
        } else if (obstaculo == TipoObstaculoMapa.FOGATA) {
            crearFogatas();
        }

        inicializarOleada1();
    }

    // ==================== CONFIGURACIÓN ====================

    /**
     * Crea las frutas de ambas oleadas en posiciones fijas
     */
    private void configurarFrutasEnOleadas(TipoFruta tipo1, TipoFruta tipo2) {
        // OLEADA 1: 8 frutas tipo 1 en posiciones fijas
        for (int i = 0; i < POSICIONES_OLEADA_1.length; i++) {
            int x = POSICIONES_OLEADA_1[i][0];
            int y = POSICIONES_OLEADA_1[i][1];
            frutas.add(crearFruta(tipo1, x, y));
        }
        
        // OLEADA 2: 8 frutas tipo 2 en posiciones fijas
        for (int i = 0; i < POSICIONES_OLEADA_2.length; i++) {
            int x = POSICIONES_OLEADA_2[i][0];
            int y = POSICIONES_OLEADA_2[i][1];
            Fruta fruta = crearFruta(tipo2, x, y);
            fruta.activa = false; // Inactiva temporalmente (NO recolectada)
            frutas.add(fruta);
        }
        
        totalFrutas = 16; // 8 + 8
    }

    /**
     * Crea una fruta según el tipo
     */
    private Fruta crearFruta(TipoFruta tipo, int x, int y) {
        if (tipo == TipoFruta.UVA) {
            return new Uvas(x, y);
        } else if (tipo == TipoFruta.BANANO) {
            return new Banano(x, y);
        } else if (tipo == TipoFruta.CEREZA) {
            return new Cereza(x, y, mapa);
        } else if (tipo == TipoFruta.PINA) {
            return new Pina(x, y, mapa);
        } else if (tipo == TipoFruta.CACTUS) {
            return new Cactus(x, y);
        }
        return new Uvas(x, y); // Por defecto
    }

    private void configurarEnemigo(TipoEnemigo tipo) throws GameException {
        if (tipo == TipoEnemigo.TROLL) {
            enemigos.add(new Troll(2, 2, mapa));
        } else if (tipo == TipoEnemigo.MACETA) {
            enemigos.add(new Maceta(12, 2, mapa, helado));
        } else if (tipo == TipoEnemigo.CALAMAR) {
            enemigos.add(new Calamar(12, 2, mapa, helado));
        }
    }

    private void crearBaldosasCalientes() {
        for (int x = 2; x <= 6; x++) {
            baldosasCalientes.add(new BaldosaCaliente(x, 3));
        }
        for (int x = 8; x <= 12; x++) {
            baldosasCalientes.add(new BaldosaCaliente(x, 3));
        }
        
        for (int x = 2; x <= 6; x++) {
            baldosasCalientes.add(new BaldosaCaliente(x, 7));
        }
        for (int x = 8; x <= 12; x++) {
            baldosasCalientes.add(new BaldosaCaliente(x, 7));
        }
        
        for (int x = 3; x <= 6; x++) {
            baldosasCalientes.add(new BaldosaCaliente(x, 11));
        }
        for (int x = 8; x <= 11; x++) {
            baldosasCalientes.add(new BaldosaCaliente(x, 11));
        }
    }

    private void crearFogatas() {
        fogatas.add(new Fogata(3, 3));
        fogatas.add(new Fogata(7, 3));
        fogatas.add(new Fogata(11, 3));
        
        fogatas.add(new Fogata(2, 7));
        fogatas.add(new Fogata(12, 7));
        
        fogatas.add(new Fogata(7, 11));
    }

    // ==================== OLEADAS ====================

    /**
     * Inicializa mostrando solo la oleada 1 (primeras 8 frutas)
     */
    private void inicializarOleada1() {
        // Las primeras 8 frutas ya están activas
        // Las últimas 8 están inactivas
        frutasRecolectadas = 0;
    }

    /**
     * Verifica si se completó la oleada 1 y activa la oleada 2
     */
    private void verificarCambioOleada() {
        if (oleada1Completa) return; 

        // Contar cuántas frutas de la oleada 1 fueron recolectadas
        int recolectadasOleada1 = 0;
        for (int i = 0; i < 8; i++) { // Primeras 8 frutas
            if (frutasRecolectadasArray[i]) {
                recolectadasOleada1++;
            }
        }

        // Si todas las frutas de la oleada 1 fueron recolectadas
        if (recolectadasOleada1 == 8) {
            oleada1Completa = true;
            activarOleada2();
        }
    }

    /**
     * Activa todas las frutas de la oleada 2
     */
    private void activarOleada2() {
        for (int i = 8; i < 16; i++) { // Últimas 8 frutas
            Fruta fruta = frutas.get(i);
            fruta.activa = true; // Activar para la oleada 2
        }
    }

    // ==================== ACTUALIZACIÓN ====================

    public void actualizar() {
        for (int i = 0; i < frutas.size(); i++) {
            frutas.get(i).actualizar();
        }
        
        for (int i = 0; i < enemigos.size(); i++) {
            enemigos.get(i).actualizar();
        }
        
        for (int i = 0; i < fogatas.size(); i++) {
            fogatas.get(i).actualizar();
        }
        
        for (int i = 0; i < baldosasCalientes.size(); i++) {
            baldosasCalientes.get(i).derretirBloque(mapa);
        }

        verificarCambioOleada();

        // Contar frutas recolectadas (solo las que fueron marcadas como recolectadas)
        int conteo = 0;
        for (int i = 0; i < frutasRecolectadasArray.length; i++) {
            if (frutasRecolectadasArray[i]) {
                conteo++;
            }
        }
        frutasRecolectadas = conteo;
    }

    // ==================== COLISIONES ====================

    public Fruta verificarColisionFrutas(Helado helado) {
        for (int i = 0; i < frutas.size(); i++) {
            Fruta fruta = frutas.get(i);
            if (fruta.isActiva() && fruta.getX() == helado.getX() && fruta.getY() == helado.getY()) {
                if (fruta instanceof Cactus) {
                    Cactus c = (Cactus) fruta;
                    if (c.esPeligroso()) {
                        helado.morir();
                        return null;
                    } else if (c.puedeSerRecolectado()) {
                        frutasRecolectadasArray[i] = true; // Marcar como recolectada
                        return fruta;
                    }
                } else {
                    frutasRecolectadasArray[i] = true; // Marcar como recolectada
                    return fruta;
                }
            }
        }
        return null;
    }

    public boolean verificarColisionEnemigos(Helado helado) {
        for (int i = 0; i < enemigos.size(); i++) {
            Enemigo enemigo = enemigos.get(i);
            if (enemigo.isActivo() && enemigo.getX() == helado.getX() && enemigo.getY() == helado.getY()) {
                return true;
            }
        }
        return false;
    }

    public boolean verificarColisionFogatas(Helado helado) {
        for (int i = 0; i < fogatas.size(); i++) {
            Fogata fogata = fogatas.get(i);
            if (fogata.eliminaHelado(helado)) {
                return true;
            }
        }
        return false;
    }

    public boolean nivelCompletado() {
        // Verificar si todas las 16 frutas fueron recolectadas
        for (int i = 0; i < frutasRecolectadasArray.length; i++) {
            if (!frutasRecolectadasArray[i]) {
                return false;
            }
        }
        return true;
    }
    
// ==================== MOVER PIÑAS ====================
    
    /**
     * Mueve todas las piñas activas en dirección opuesta al helado
     */
    public void moverPinas(String direccionHelado) {
        for (int i = 0; i < frutas.size(); i++) {
            Fruta fruta = frutas.get(i);
            if (fruta instanceof Pina && fruta.isActiva()) {
                ((Pina) fruta).moverConHelado(direccionHelado);
            }
        }
    }



    // ==================== GETTERS ====================

    public Mapa getMapa() { return mapa; }
    public ArrayList<Fruta> getFrutas() { return frutas; }
    public ArrayList<Enemigo> getEnemigos() { return enemigos; }
    public ArrayList<Fogata> getFogatas() { return fogatas; }
    public ArrayList<BaldosaCaliente> getBaldosasCalientes() { return baldosasCalientes; }
    public int getFrutasRecolectadas() { return frutasRecolectadas; }
    public int getTotalFrutas() { return totalFrutas; }
    public int getNumeroNivel() { return numeroNivel; }
}