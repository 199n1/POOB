package logic;

/**
 * Clase que maneja el temporizador del juego.
 * 
 * Cada nivel tiene un máximo de 3 minutos (180 segundos) para completarse.
 * Este reloj cuenta hacia atrás y avisa cuando el tiempo se agota.
 */
public class ManejadorTiempo {

    private int framesPorSegundo = 60;      // El juego corre a 60 FPS
    private int tiempoMaximoSegundos = 180; // 3 minutos por nivel
    private int framesTranscurridos;        // Cuántos frames han pasado
    private boolean pausado;
    private boolean tiempoAgotado;

    /**
     * Crea un nuevo temporizador listo para usar.
     * 
     * Empieza en 0 segundos y no está pausado.
     */
    public ManejadorTiempo() {
        this.framesTranscurridos = 0;
        this.pausado = false;
        this.tiempoAgotado = false;
    }

    /**
     * Actualiza el temporizador .
     * 
     * Suma 1 frame al contador y verifica si ya se acabó el tiempo.
     * Si el temporizador está pausado o ya se agotó, no hace nada.
     */
    public void actualizar() {
        if (pausado || tiempoAgotado) {
            return;
        }

        framesTranscurridos++;

        // Si llegamos a 0 segundos, marcamos que se acabó el tiempo
        if (getSegundosRestantes() <= 0) {
            tiempoAgotado = true;
        }
    }

    /**
     * Calcula cuántos segundos han pasado desde que empezó el nivel.
     * 
     * @return Segundos transcurridos
     */
    public int getSegundosTranscurridos() {
        return framesTranscurridos / framesPorSegundo;
    }

    /**
     * Calcula cuántos segundos quedan para que se acabe el tiempo.
     * 
     * @return Segundos restantes (mínimo 0)
     */
    public int getSegundosRestantes() {
        int transcurridos = getSegundosTranscurridos();
        int restantes = tiempoMaximoSegundos - transcurridos;
        return Math.max(0, restantes); // No puede ser negativo
    }

    /**
     * Devuelve el tiempo restante en formato "minutos:segundos".
     * 
     * Ejemplo: "2:45" significa 2 minutos y 45 segundos
     * 
     * @return Tiempo formateado como String
     */
    public String getTiempoFormateado() {
        int segundosRestantes = getSegundosRestantes();
        int minutos = segundosRestantes / 60;
        int segundos = segundosRestantes % 60;
        
        // %02d significa "muestra 2 dígitos, rellena con 0 si hace falta"
        // Así 5 segundos se muestra como "05" en vez de "5"
        return String.format("%d:%02d", minutos, segundos);
    }

    /**
     * Verifica si ya se acabó el tiempo.
     * 
     * @return true si llegamos a 0:00, false si todavía hay tiempo
     */
    public boolean tiempoAgotado() {
        return tiempoAgotado;
    }

    /**
     * Pausa el temporizador (deja de contar).
     */
    public void pausar() {
        pausado = true;
    }

    /**
     * Reanuda el temporizador después de una pausa.
     */
    public void reanudar() {
        pausado = false;
    }

    /**
     * Verifica si el temporizador está pausado actualmente.
     * 
     * @return true si está pausado, false si está corriendo
     */
    public boolean estaPausado() {
        return pausado;
    }

    /**
     * Reinicia el temporizador a 0 segundos.
     * 
     * Útil cuando empiezas un nuevo nivel.
     */
    public void reiniciar() {
        framesTranscurridos = 0;
        pausado = false;
        tiempoAgotado = false;
    }

    /**
     * Cambia el tiempo máximo del nivel.
     * 
     * Por defecto son 180 segundos (3 minutos), pero puedes ajustarlo.
     * 
     * @param segundos Nuevo tiempo máximo en segundos
     */
    public void setTiempoMaximo(int segundos) {
        this.tiempoMaximoSegundos = segundos;
    }

    /**
     * Calcula qué porcentaje del tiempo queda.
     * 
     * Útil para dibujar una barra de progreso.
     * 
     * @return Valor entre 0.0 (tiempo agotado) y 1.0 (tiempo completo)
     */
    public double getPorcentajeTiempo() {
        return (double) getSegundosRestantes() / tiempoMaximoSegundos;
    }

    /**
     * Verifica si quedan menos de 30 segundos.
     * 
     * Esto sirve para mostrar una alerta o cambiar el color del reloj
     * cuando el tiempo se está acabando.
     * 
     * @return true si quedan menos de 30 segundos, false si hay más tiempo
     */
    public boolean tiempoEnAlerta() {
        return getSegundosRestantes() < 30 && getSegundosRestantes() > 0;
    }
}