package domain;

/**
 * Maceta: Persigue al helado pero NO rompe bloques
 */
public class Maceta extends Enemigo {
    private Helado objetivo;
    private int contadorFrames;

    public Maceta(int x, int y, Mapa mapa, Helado objetivo) throws GameException {
        super(x, y, mapa);
        this.objetivo = objetivo;
        this.contadorFrames = 0;
    }

    @Override
    public void actualizar() {
        if (!activo) return;
        contadorFrames++;
        if (contadorFrames >= 20) { // Cada 0.33 segundos
            mover();
            contadorFrames = 0;
        }
    }

    @Override
    public void mover() {
        if (objetivo == null || !objetivo.isVivo()) return;

        // Calcular diferencia de posición
        int dx = objetivo.getX() - x;
        int dy = objetivo.getY() - y;

        int nx = x;
        int ny = y;

        // Moverse hacia el helado (prioridad horizontal o vertical)
        if (Math.abs(dx) > Math.abs(dy)) {
            // Moverse horizontalmente
            if (dx > 0) {
                nx++;
                direccion = "derecha";
            } else if (dx < 0) {
                nx--;
                direccion = "izquierda";
            }
        } else {
            // Moverse verticalmente
            if (dy > 0) {
                ny++;
                direccion = "abajo";
            } else if (dy < 0) {
                ny--;
                direccion = "arriba";
            }
        }

        // Solo moverse si la posición está libre (NO rompe bloques)
        if (posicionValida(nx, ny)) {
            x = nx;
            y = ny;
        }
    }
}