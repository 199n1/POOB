package domain;

/**
 *  crea mapas diferentes según el tipo de obstáculo elegido
 * - Bloques de hielo
 * - Baldosas calientes
 * - Fogatas
 */
public class Mapa {
    private BloqueHielo[][] bloques;
    private int ancho;
    private int alto;
    private int numeroNivel;
    private TipoObstaculoMapa tipo;

    public Mapa(int ancho, int alto, int numeroNivel, TipoObstaculoMapa tipo) throws GameException {
        if (ancho <= 0 || alto <= 0) {
            throw GameException.errorMapa("Dimensiones inválidas");
        }
        this.ancho = ancho;
        this.alto = alto;
        this.numeroNivel = numeroNivel;
        this.tipo = tipo;
        this.bloques = new BloqueHielo[alto][ancho];
        
        // Crear el mapa según el tipo de obstáculo elegido
        switch (tipo) {
            case HIELO:
                inicializarMapaHielo();
                break;
            case BALDOSA_CALIENTE:
                inicializarMapaBaldosas();
                break;
            case FOGATA:
                inicializarMapaFogatas();
                break;
        }
    }

    /**
     * Mapa para BLOQUES DE HIELO
     * Solo bordes permanentes y formas en L (como en tu imagen)
     */
    private void inicializarMapaHielo() {
        // BORDES PERMANENTES (todo alrededor)
        for (int i = 0; i < alto; i++) {
            bloques[i][0] = new BloqueHielo(0, i, true);           // Borde izquierdo
            bloques[i][ancho - 1] = new BloqueHielo(ancho - 1, i, true); // Borde derecho
        }
        for (int j = 0; j < ancho; j++) {
            bloques[0][j] = new BloqueHielo(j, 0, true);           // Borde superior
            bloques[alto - 1][j] = new BloqueHielo(j, alto - 1, true); // Borde inferior
        }
        
        // FORMA EN L SUPERIOR IZQUIERDA
        crearBloqueVertical(3, 3, 5);    // Línea vertical
        crearBloqueHorizontal(3, 3, 4);  // Línea horizontal
        
        // FORMA EN L SUPERIOR DERECHA
        crearBloqueVertical(11, 3, 5);   // Línea vertical
        crearBloqueHorizontal(8, 3, 4);  // Línea horizontal
        
        // FORMA EN L INFERIOR IZQUIERDA
        crearBloqueVertical(3, 10, 2);   // Línea vertical pequeña
        crearBloqueHorizontal(3, 10, 4); // Línea horizontal
        
        // FORMA EN L INFERIOR DERECHA
        crearBloqueVertical(11, 10, 2);  // Línea vertical pequeña
        crearBloqueHorizontal(8, 10, 4); // Línea horizontal
    }

    /**
     * Mapa para BALDOSAS CALIENTES
     * SOLO BORDES, sin bloques internos
     */
    private void inicializarMapaBaldosas() {
        // SOLO BORDES PERMANENTES
        for (int i = 0; i < alto; i++) {
            bloques[i][0] = new BloqueHielo(0, i, true);
            bloques[i][ancho - 1] = new BloqueHielo(ancho - 1, i, true);
        }
        for (int j = 0; j < ancho; j++) {
            bloques[0][j] = new BloqueHielo(j, 0, true);
            bloques[alto - 1][j] = new BloqueHielo(j, alto - 1, true);
        }
        // No se agregan bloques internos
    }

    /**
     * Mapa para FOGATAS
     * SOLO BORDES, mapa completamente abierto
     */
    private void inicializarMapaFogatas() {
        // SOLO BORDES PERMANENTES
        for (int i = 0; i < alto; i++) {
            bloques[i][0] = new BloqueHielo(0, i, true);
            bloques[i][ancho - 1] = new BloqueHielo(ancho - 1, i, true);
        }
        for (int j = 0; j < ancho; j++) {
            bloques[0][j] = new BloqueHielo(j, 0, true);
            bloques[alto - 1][j] = new BloqueHielo(j, alto - 1, true);
        }
        // No se agregan bloques internos
    }

    /**
     * Crea una línea vertical de bloques (NO permanentes)
     */
    private void crearBloqueVertical(int x, int yInicio, int longitud) {
        for (int i = 0; i < longitud; i++) {
            int y = yInicio + i;
            if (dentroLimites(x, y) && bloques[y][x] == null) {
                bloques[y][x] = new BloqueHielo(x, y, false);
            }
        }
    }

    /**
     * Crea una línea horizontal de bloques (NO permanentes)
     */
    private void crearBloqueHorizontal(int xInicio, int y, int longitud) {
        for (int i = 0; i < longitud; i++) {
            int x = xInicio + i;
            if (dentroLimites(x, y) && bloques[y][x] == null) {
                bloques[y][x] = new BloqueHielo(x, y, false);
            }
        }
    }

    public boolean dentroLimites(int x, int y) {
        return x >= 0 && x < ancho && y >= 0 && y < alto;
    }

    public BloqueHielo getBloque(int x, int y) {
        if (!dentroLimites(x, y)) return null;
        return bloques[y][x];
    }

    public void setBloque(int x, int y, BloqueHielo bloque) {
        if (dentroLimites(x, y)) {
            bloques[y][x] = bloque;
        }
    }

    public boolean posicionLibre(int x, int y) {
        if (!dentroLimites(x, y)) return false;
        BloqueHielo bloque = bloques[y][x];
        return bloque == null || !bloque.isActivo();
    }

    public TipoObstaculoMapa getTipo() { 
        return tipo; 
    }
    
    public BloqueHielo[][] getBloques() { 
        return bloques; 
    }
    
    public int getAncho() { 
        return ancho; 
    }
    
    public int getAlto() { 
        return alto; 
    }
    
    public int getNumeroNivel() { 
        return numeroNivel; 
    }
}