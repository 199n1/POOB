package logic;

import domain.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Motor principal del juego Bad Dopo Cream.
 * 
 * Esta clase controla todo lo que pasa en el juego: los niveles, los helados,
 * el puntaje, el tiempo y las reglas. Es como el cerebro del juego.
 * 
 * Puede manejar dos modos:
 * - "Player": un solo jugador contra enemigos
 * - "PvsP": dos jugadores compitiendo entre sí
 */
public class GameEngine implements Serializable {
    private static final long serialVersionUID = 1L;

    
    private Nivel nivelActual;
    private int numeroNivel;
    private int puntajeTotal;
    private boolean pausado;
    private boolean juegoTerminado;
    private boolean nivelCompletado;

    // === CONFIGURACIÓN DE JUGADORES ====
    
    private String modalidad;  // "Player" o "PvsP"
    private Helado helado;     // Jugador 1
    private Helado helado2;    // Jugador 2 (solo existe en modo PvsP)
    private String colorHelado;

    // ==== SISTEMA DE TIEMPO =
    
    private ManejadorTiempo temporizador;

    // ==== CONFIGURACIÓN DE NIVELES =====
    // Estas listas guardan qué obstáculos, frutas y enemigos aparecen en cada nivel
    
    private List<TipoObstaculoMapa> obstaculosPorNivel;
    private List<TipoFruta[]> frutasPorNivel;
    private List<TipoEnemigo> enemigoPorNivel;

    /**
     * Crea un nuevo juego de Bad Dopo Cream.
     * 
     * @param modalidad Tipo de juego: "Player" para un jugador o "PvsP" para dos jugadores
     * @param colorHelado Color del helado del jugador 1 (ejemplo: "Vainilla", "Fresa")
     * @throws GameException Si hay algún error al iniciar el juego
     */
    public GameEngine(String modalidad, String colorHelado) throws GameException {
        this.modalidad = modalidad;
        this.colorHelado = colorHelado;
        this.puntajeTotal = 0;
        this.numeroNivel = 1;
        this.pausado = false;
        this.juegoTerminado = false;
        this.nivelCompletado = false;
        this.temporizador = new ManejadorTiempo();
        
        // Inicializamos las listas de configuración de niveles
        this.obstaculosPorNivel = new ArrayList<>();
        this.frutasPorNivel = new ArrayList<>();
        this.enemigoPorNivel = new ArrayList<>();
        
        // Configuramos los 3 niveles con sus características
        configuracionPorDefecto();
        
        // Arrancamos desde el nivel 1
        iniciarNivel(1);
    }

    /**
     * Define la configuración por defecto de los 3 niveles del juego.
     * 
     * Nivel 1: Hielo, uvas y bananos, enemigo Troll
     * Nivel 2: Baldosas calientes, cerezas y piñas, enemigo Maceta
     * Nivel 3: Fogatas, piñas y cactus, enemigo Calamar
     */
    private void configuracionPorDefecto() {
        setConfiguracionNivel(0, TipoObstaculoMapa.HIELO, TipoFruta.UVA, TipoFruta.BANANO, TipoEnemigo.TROLL);
        setConfiguracionNivel(1, TipoObstaculoMapa.BALDOSA_CALIENTE, TipoFruta.CEREZA, TipoFruta.PINA, TipoEnemigo.MACETA);
        setConfiguracionNivel(2, TipoObstaculoMapa.FOGATA, TipoFruta.PINA, TipoFruta.CACTUS, TipoEnemigo.CALAMAR);
    }

    /**
     * Configura qué obstáculos, frutas y enemigos aparecen en un nivel específico.
     * 
     * Este método es útil cuando quieras agregar nuevos niveles o modificar los existentes.
     * 
     * @param nivelIndex Índice del nivel (0 para nivel 1, 1 para nivel 2, etc.)
     * @param obstaculo Tipo de obstáculo que aparecerá en el mapa
     * @param fruta1 Primera fruta que se puede recolectar
     * @param fruta2 Segunda fruta que se puede recolectar
     * @param enemigo Tipo de enemigo que perseguirá al helado
     */
    public void setConfiguracionNivel(int nivelIndex, TipoObstaculoMapa obstaculo, 
                                     TipoFruta fruta1, TipoFruta fruta2, TipoEnemigo enemigo) {
        // Nos aseguramos de que las listas tengan espacio suficiente
        ensureSize(nivelIndex + 1);
        
        // Guardamos la configuración en la posición correcta
        obstaculosPorNivel.set(nivelIndex, obstaculo);
        frutasPorNivel.set(nivelIndex, new TipoFruta[]{fruta1, fruta2});
        enemigoPorNivel.set(nivelIndex, enemigo);
    }

    /**
     * Asegura que las listas de configuración tengan el tamaño necesario.
     * 
     * Si las listas son muy pequeñas, las agranda y rellena con valores por defecto.
     * 
     * @param size Tamaño mínimo que deben tener las listas
     */
    private void ensureSize(int size) {
        while (obstaculosPorNivel.size() < size) {
            obstaculosPorNivel.add(TipoObstaculoMapa.HIELO);
        }
        while (frutasPorNivel.size() < size) {
            frutasPorNivel.add(new TipoFruta[]{TipoFruta.UVA, TipoFruta.BANANO});
        }
        while (enemigoPorNivel.size() < size) {
            enemigoPorNivel.add(TipoEnemigo.TROLL);
        }
    }

    /**
     * Inicia un nivel específico del juego.
     * 
     * Crea el mapa, coloca al helado (o helados en modo PvsP) en sus posiciones iniciales,
     * genera los obstáculos, frutas y enemigos según la configuración del nivel.
     * 
     * @param numeroNivel Número del nivel a iniciar (1, 2, 3, etc.)
     * @throws GameException Si hay algún error al crear el nivel
     */
    public void iniciarNivel(int numeroNivel) throws GameException {
        this.numeroNivel = numeroNivel;
        this.nivelCompletado = false;

        // Aseguramos que exista configuración para este nivel
        ensureSize(numeroNivel);
        
        // Obtenemos la configuración del nivel (restamos 1 porque las listas empiezan en 0)
        TipoObstaculoMapa obstaculo = obstaculosPorNivel.get(numeroNivel - 1);
        TipoFruta[] frutas = frutasPorNivel.get(numeroNivel - 1);
        TipoEnemigo enemigo = enemigoPorNivel.get(numeroNivel - 1);

        // Creamos el helado jugador 1 en la posición (3, 7)
        String sabor = colorHelado != null ? colorHelado : "Vainilla";
        helado = new Helado(3, 7, null, sabor);

        // Si estamos en modo PvsP, creamos el helado jugador 2 en la posición (11, 7)
        if (modalidad.equals("PvsP")) {
            helado2 = new Helado(11, 7, null, "Chocolate");
        } else {
            helado2 = null;
        }

        // Creamos el nivel con toda su configuración
        nivelActual = new Nivel(numeroNivel, helado, obstaculo, frutas[0], frutas[1], enemigo);
        
        // Conectamos los helados con el mapa del nivel para que puedan moverse
        helado.setMapa(nivelActual.getMapa());
        if (helado2 != null) {
            helado2.setMapa(nivelActual.getMapa());
        }

        // Reiniciamos el temporizador y quitamos la pausa
        temporizador.reiniciar();
        pausado = false;
    }

    /**
     * Actualiza el estado del juego cada frame (cada vez que se dibuja la pantalla).
     * 
     * Este método se llama aproximadamente 60 veces por segundo y se encarga de:
     * - Actualizar el temporizador
     * - Mover enemigos y objetos
     * - Verificar colisiones
     * - Revisar si se completó el nivel o se acabó el tiempo
     */
    public void actualizar() {
        // No actualizamos si el juego está pausado, terminado o no hay nivel
        if (pausado || juegoTerminado || nivelActual == null) return;

        // Actualizamos el reloj del juego
        temporizador.actualizar();
        
        // Actualizamos todo lo que pasa en el nivel (enemigos, animaciones, etc.)
        nivelActual.actualizar();

        // Verificamos colisiones y reglas para jugador 1
        verificarReglas(helado);
        
        // Verificamos colisiones y reglas para jugador 2 (si existe)
        if (helado2 != null) {
            verificarReglas(helado2);
        }

        // Verificamos si ya se recolectaron todas las frutas
        if (nivelActual.nivelCompletado()) {
            nivelCompletado = true;
        }

        // Verificamos si se acabó el tiempo
        if (temporizador.tiempoAgotado()) {
            nivelCompletado = true;
        }
    }

    /**
     * Verifica las reglas del juego para un helado específico.
     * 
     * Revisa si el helado chocó con enemigos, fogatas o frutas,
     * y aplica las consecuencias (perder, ganar puntos, etc.).
     * 
     * @param h El helado que queremos verificar (puede ser jugador 1 o 2)
     */
    private void verificarReglas(Helado h) {
        // Si el helado no existe o ya murió, no hacemos nada
        if (h == null || !h.isVivo()) return;

        // Si el helado toca un enemigo, muere y se termina el juego
        if (nivelActual.verificarColisionEnemigos(h)) {
            h.morir();
            juegoTerminado = true;
            return;
        }

        // Si el helado toca una fogata, se derrite y se termina el juego
        if (nivelActual.verificarColisionFogatas(h)) {
            h.morir();
            juegoTerminado = true;
            return;
        }

        // Si el helado toca una fruta, la recolecta y suma puntos
        Fruta f = nivelActual.verificarColisionFrutas(h);
        if (f != null && f.isActiva()) {
            // Los cactus solo se pueden recolectar cuando están maduros
            if (!(f instanceof Cactus) || ((Cactus) f).puedeSerRecolectado()) {
                f.recolectar();
                puntajeTotal = puntajeTotal + f.getPuntos();
            }
        }
    }

    // ==== CONTROL DEL JUEGO ===

    /**
     * Mueve al helado del jugador 1 en la dirección indicada.
     * 
     * También mueve las piñas si el helado las empuja.
     * 
     * @param direccion "arriba", "abajo", "izquierda" o "derecha"
     */
    public void moverHelado(String direccion) {
        if (helado != null && helado.isVivo()) {
            helado.mover(direccion);
            
            // IMPORTANTE: Las piñas se mueven después del helado
            // para que se empujen correctamente
            if (nivelActual != null) {
                nivelActual.moverPinas(direccion);
            }
        }
    }

    /**
     * El helado crea o destruye bloques de hielo.
     * 
     */
    public void accionBloque() {
        if (helado != null && helado.isVivo()) {
            helado.crearBloques();
        }
    }

    /**
     * Avanza al siguiente nivel del juego.
     * 
     * Si ya no hay más niveles, termina el juego.
     * 
     * @throws GameException Si hay algún error al cargar el siguiente nivel
     */
    public void siguienteNivel() throws GameException {
        int siguiente = numeroNivel + 1;
        
        // Solo hay 3 niveles, si llegamos al 4 se terminó el juego
        if (siguiente > 3) {
            juegoTerminado = true;
        } else {
            iniciarNivel(siguiente);
        }
    }

    /**
     * Reinicia el juego desde el principio.
     * 
     * Vuelve al nivel 1 y resetea el puntaje a 0.
     * 
     * @throws GameException Si hay algún error al reiniciar
     */
    public void reiniciarJuego() throws GameException {
        puntajeTotal = 0;
        juegoTerminado = false;
        nivelCompletado = false;
        iniciarNivel(1);
    }

    // ==================== GETTERS ====================
    // Estos métodos permiten consultar el estado del juego

    public Nivel getNivel() { return nivelActual; }
    public Nivel getNivelActual() { return nivelActual; }
    public int getNumeroNivel() { return numeroNivel; }
    public int getPuntaje() { return puntajeTotal; }
    public int getPuntajeTotal() { return puntajeTotal; }
    public int getVidasRestantes() { return 0; }
    public boolean isPausado() { return pausado; }
    public boolean isJuegoTerminado() { return juegoTerminado; }
    public boolean isGameOver() { return juegoTerminado; }
    public boolean isNivelCompletado() { return nivelCompletado; }
    public Helado getHelado() { return helado; }
    public Helado getHelado1() { return helado; }
    public Helado getHelado2() { return helado2; }
    public ManejadorTiempo getTemporizador() { return temporizador; }
    public String getModalidad() { return modalidad; }
    
    /**
     * Devuelve cuántas frutas se han recolectado en el nivel actual.
     */
    public int getFrutasRecolectadas() {
        if (nivelActual == null) return 0;
        return nivelActual.getFrutasRecolectadas();
    }
    
    /**
     * Devuelve el tiempo restante en formato "minutos:segundos" (ejemplo: "2:45").
     */
    public String getTiempoRestante() {
        return temporizador.getTiempoFormateado();
    }
    
    /**
     * Verifica si el jugador completó todos los niveles del juego.
     */
    public boolean juegoCompletado() {
        return numeroNivel >= 3 && nivelCompletado;
    }

    /** Pausa el juego (todo se congela). */
    public void pausar() { pausado = true; }
    
    /** Reanuda el juego después de una pausa. */
    public void reanudar() { pausado = false; }
    
    /** Termina el juego inmediatamente. */
    public void terminar() { juegoTerminado = true; }
}