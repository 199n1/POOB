package domain;

/**
 * Fogata 
 */
public class Fogata {
    private int x, y;
    private boolean encendida;
    private boolean activa;
    private int contadorFrames;
    private static final int FRAMES_REENCENDIDO = 600; // 10 segundos
    
    public Fogata(int x, int y) {
        this.x = x;
        this.y = y;
        this.encendida = true;
        this.activa = true;
        this.contadorFrames = 0;
    }
    
    public void actualizar() {
        if (!encendida) {
            contadorFrames++;
            if (contadorFrames >= FRAMES_REENCENDIDO) {
                encenderse();
            }
        }
    }
    
    public void apagar() {
        if (encendida) {
            encendida = false;
            contadorFrames = 0;
        }
    }
    
    public void encenderse() {
        encendida = true;
        contadorFrames = 0;
    }
    
    public boolean estaEncendida() {
        return encendida && activa;
    }
    
    public boolean eliminaHelado(Helado helado) {
        return encendida && activa && 
               helado.getX() == x && helado.getY() == y;
    }
    
    public boolean isActivo() { return activa; }
    public int getX() { return x; }
    public int getY() { return y; }
    public void setEncendida(boolean encendida) { this.encendida = encendida; }
}