package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Menu principal del juego 
 */
public class MenuPrincipal extends JFrame {
    
    private JButton btnIniciar;
    private Image fondoImagen;
    
    public MenuPrincipal() {
        cargarFondo();
        configurarVentana();
        inicializarComponentes();
    }
    
    private void cargarFondo() {
        try {
            java.net.URL imgURL = getClass().getResource("/resources/imagenes/fondo_menu.png");
            if (imgURL != null) {
                fondoImagen = new ImageIcon(imgURL).getImage();
                System.out.println("Fondo cargado exitosamente");
            } else {
                System.err.println("No se encontro: /resources/imagenes/fondo_menu.png");
            }
        } catch (Exception e) {
            System.err.println("Error al cargar fondo: " + e.getMessage());
        }
    }
    
    private void configurarVentana() {
        setTitle("Bad DOPO Cream");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (fondoImagen != null) {
                    g.drawImage(fondoImagen, 0, 0, getWidth(), getHeight(), this);
                } else {
                    g.setColor(new Color(200, 230, 255));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        
        panelPrincipal.setLayout(null);
        panelPrincipal.setOpaque(false);
        
        btnIniciar = new JButton("INICIAR");
        btnIniciar.setFont(new Font("Arial", Font.BOLD, 24));
        btnIniciar.setBounds(140, 340, 220, 55);
        btnIniciar.setBackground(new Color(46, 204, 113));
        btnIniciar.setForeground(Color.WHITE);
        btnIniciar.setFocusPainted(false);
        btnIniciar.setBorderPainted(true);
        btnIniciar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(39, 174, 96), 3),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        
        // Action listener
        btnIniciar.addActionListener(new ListenerIniciar(this));
        
        panelPrincipal.add(btnIniciar);
        add(panelPrincipal);
    }
    
    // Clase interna para el ActionListener del boton Iniciar
    private class ListenerIniciar implements ActionListener {
        private MenuPrincipal ventana;
        
        public ListenerIniciar(MenuPrincipal ventana) {
            this.ventana = ventana;
        }
        
        public void actionPerformed(ActionEvent e) {
            ventana.dispose();
            PantallaSeleccionModalidad pantalla = new PantallaSeleccionModalidad();
            pantalla.setVisible(true);
        }
    }
    

    
    public static void main(String[] args) {
        MenuPrincipal menu = new MenuPrincipal();
        menu.setVisible(true);
    }
}