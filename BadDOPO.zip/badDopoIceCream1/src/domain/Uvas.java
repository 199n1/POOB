package domain;

/**
 * Uvas: fruta estática que otorga 50 puntos
 */
public class Uvas extends Fruta {
    public Uvas(int x, int y) { super(x, y, 50); }

    @Override
    public String getTipo() { return "Uvas"; }

    @Override
    public void actualizar() { /* no hace nada */ }
}
